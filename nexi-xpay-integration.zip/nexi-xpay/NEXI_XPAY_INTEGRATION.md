# Nexi XPay HPP — Documentazione Integrazione

## Panoramica

Questa integrazione utilizza la modalità **Hosted Payment Page (HPP)** di Nexi XPay.  
Il cliente viene reindirizzato sulla pagina di pagamento sicura di Nexi per inserire i dati della carta.  
Il nostro sito **non tocca mai i dati della carta** — tutta la gestione avviene su Nexi.

### Perché HPP e non XPay Build v3?

| Modalità | Problema |
|---|---|
| XPay Build v3 (iframe) | Richiede cookie di terze parti, bloccati da Chrome/Safari/Firefox |
| **HPP (redirect)** | Nessun cookie di terze parti — funziona su tutti i browser ✓ |

---

## Variabili d'Ambiente Richieste

| Variabile | Descrizione | Esempio |
|---|---|---|
| `NEXI_API_KEY` | Chiave API Nexi XPay (produzione o sandbox) | `2e570a58-9914-477a-9ede-35baff23a376` |
| `NEXI_ENV` | Ambiente: `production` o `sandbox` | `production` |

### Chiavi di Test (Sandbox)
- **Capture implicito:** `2e570a58-9914-477a-9ede-35baff23a376`
- **Capture esplicito:** `ee6a41f2-fa09-4b8f-bc05-5dc225bdc270`

---

## Endpoint API

### Base URL

| Ambiente | URL Base |
|---|---|
| Produzione | `https://xpay.nexigroup.com/api/phoenix-0.0/psp/api/v1` |
| Sandbox | `https://xpaysandbox.nexigroup.com/api/phoenix-0.0/psp/api/v1` |

### Headers richiesti per ogni chiamata

```http
Content-Type: application/json
X-Api-Key: {NEXI_API_KEY}
Correlation-Id: {UUID univoco per ogni richiesta}
```

---

## Flusso di Pagamento Completo

```
Cliente riempie checkout
        │
        ▼
POST /api/checkout/create-bullion-order  (nostro server)
        │
        ▼
POST {NEXI_BASE}/orders/hpp  (server Nexi)
        │
        ▼
Nexi restituisce { hostedPage, securityToken }
        │
        ▼
Frontend reindirizza cliente su hostedPage
        │
        ▼
Cliente inserisce carta su pagina sicura Nexi
        │
        ├─── Pagamento OK ──► Nexi reindirizza su resultUrl
        │                              │
        │                              ▼
        │                    /order-success?orderId=...
        │
        └─── Cliente annulla ──► Nexi reindirizza su cancelUrl
                                           │
                                           ▼
                                    /cart
```

---

## Implementazione Backend

### File: `checkout-bullion.ts`

**Rotta:** `POST /api/checkout/create-bullion-order`

```typescript
// 1. Calcola importo totale in centesimi
const totalUsd = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
const amountCents = Math.round(totalUsd * 100);

// 2. Genera Order ID univoco (prefisso NV + 8 bytes hex)
const orderId = `NV${randomBytes(8).toString("hex").toUpperCase()}`;

// 3. Chiama Nexi HPP
const nexiResponse = await fetch(`${NEXI_BASE}/orders/hpp`, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "X-Api-Key": NEXI_API_KEY,
    "Correlation-Id": randomUUID(),   // UUID univoco per ogni richiesta!
  },
  body: JSON.stringify({
    order: {
      orderId,                         // ID univoco del tuo ordine
      amount: String(amountCents),     // Importo in centesimi come stringa
      currency: "USD",                 // Valuta ISO 4217
      description: "...",              // Max 200 caratteri
      customerInfo: {
        cardHolderName: customerName,
        cardHolderEmail: customerEmail,
      },
    },
    paymentSession: {
      actionType: "PAY",               // PAY = addebito immediato
      amount: String(amountCents),
      currency: "USD",
      language: "eng",                 // "ita" per italiano
      resultUrl: `${siteUrl}/order-success?orderId=${orderId}`,
      cancelUrl: `${siteUrl}/cart`,
      notificationUrl: `${siteUrl}/api/checkout/notify`,
    },
  }),
});

// 4. Restituisce hostedPage al frontend
const { hostedPage, securityToken } = await nexiResponse.json();
res.json({ hostedPage, orderId, amountCents });
```

### File: `checkout.ts` — Verifica pagamento (per shop con database)

**Rotta:** `GET /api/checkout/verify/:orderId`

```typescript
// Chiedi a Nexi lo stato dell'ordine
const nexiResponse = await fetch(`${NEXI_BASE}/orders/${orderId}`, {
  headers: {
    "X-Api-Key": NEXI_API_KEY,
    "Correlation-Id": randomUUID(),
  },
});

const nexiOrder = await nexiResponse.json();
const operations = nexiOrder.operations || [];
const latestOp = operations[operations.length - 1];
const operationResult = latestOp?.operationResult;

// Mappa i risultati Nexi ai tuoi stati
// AUTHORIZED / EXECUTED  → "paid"
// DECLINED / FAILED / VOIDED → "failed"
// CANCELLED → "cancelled"
// altro → "pending"
```

### File: `checkout.ts` — Webhook server-to-server

**Rotta:** `POST /api/checkout/notify`

Nexi chiama questo endpoint in modo asincrono quando il pagamento cambia stato.  
Per ora logga la notifica e risponde 200. Puoi estenderlo per aggiornare l'ordine nel database.

```typescript
router.post("/checkout/notify", async (req, res) => {
  req.log.info({ body: req.body }, "Nexi payment notification received");
  res.status(200).json({ received: true });
});
```

---

## Implementazione Frontend

### File: `checkout.tsx`

```typescript
// 1. Invia i dati al nostro server
const res = await fetch("/api/checkout/create-bullion-order", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    customerName: `${firstName} ${lastName}`,
    customerEmail: email,
    items: cartItems,
  }),
});

const { hostedPage, orderId } = await res.json();

// 2. Reindirizza su Nexi
window.location.href = hostedPage;
// oppure apri in iframe/overlay (vedi checkout.tsx per l'implementazione completa)
```

### Strategia Overlay vs Redirect

Il file `checkout.tsx` implementa prima un **iframe overlay** (Nexi appare sopra la pagina).  
Se il browser blocca l'iframe (cross-origin), mostra automaticamente un bottone per il redirect diretto.

```
overlayState:
  "idle"     → nessun overlay
  "loading"  → spinner mentre il server crea l'ordine
  "open"     → iframe con pagina Nexi
  "blocked"  → browser ha bloccato l'iframe → bottone redirect
```

---

## URLs di Ritorno

Nexi reindirizza il cliente a questi URL dopo il pagamento:

| URL | Quando |
|---|---|
| `resultUrl` = `/order-success?orderId={id}` | Pagamento completato (OK o KO) |
| `cancelUrl` = `/cart` | Cliente ha premuto "Annulla" su Nexi |
| `notificationUrl` = `/api/checkout/notify` | Notifica server-to-server (asincrona) |

> ⚠️ **Importante:** `resultUrl` viene chiamato anche per pagamenti falliti.  
> Usa sempre `GET /api/checkout/verify/:orderId` per verificare lo stato reale.

---

## Gestione Errori

| Scenario | Comportamento |
|---|---|
| `NEXI_API_KEY` non configurata | Restituisce URL mock per sviluppo, nessun pagamento reale |
| Nexi risponde non-OK | Server risponde `502` con messaggio generico |
| Cliente annulla | Redirect a `/cart` |
| Importo 0 o carrello vuoto | Server risponde `400` |

---

## Test in Sandbox

1. Imposta `NEXI_ENV=sandbox`
2. Usa la chiave sandbox: `2e570a58-9914-477a-9ede-35baff23a376`
3. Sulla pagina Nexi sandbox usa la carta di test: `4539970000000006`, scadenza qualsiasi futura, CVV `123`

---

## Passaggio a Produzione

1. Ottieni la chiave di produzione dal portale Nexi Merchant
2. Imposta `NEXI_API_KEY` = chiave di produzione (nel pannello segreti Replit)
3. Imposta `NEXI_ENV=production`
4. Verifica che `REPLIT_DOMAINS` sia configurato (usato per costruire `resultUrl` e `cancelUrl`)
5. Pubblica l'app

---

## Struttura File Integrazione

```
api-server/src/routes/
  ├── checkout-bullion.ts   Integrazione HPP per US Bullion Shop
  └── checkout.ts           Integrazione HPP + verify + webhook (con DB)

bullion-shop/src/pages/
  └── checkout.tsx          Frontend checkout con overlay iframe Nexi
```
