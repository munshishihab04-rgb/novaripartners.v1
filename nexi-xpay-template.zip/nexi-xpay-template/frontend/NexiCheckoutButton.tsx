/**
 * NEXI XPAY HPP — Componente React Checkout
 *
 * Come usare:
 *   <NexiCheckoutButton
 *     items={cartItems}
 *     customerName="Mario Rossi"
 *     customerEmail="mario@example.com"
 *   />
 *
 * Props:
 *   items           Array di prodotti nel carrello
 *   customerName    Nome completo del cliente
 *   customerEmail   Email del cliente
 *   onError?        Callback opzionale per errori
 *   className?      Classe CSS aggiuntiva per il bottone
 *   label?          Testo del bottone (default: "Paga ora")
 */

import { useState } from "react";

// ─── Tipi ─────────────────────────────────────────────────────────────────────

type CartItem = {
  id: string;
  name: string;
  price: number;
  quantity: number;
};

type NexiCheckoutButtonProps = {
  items: CartItem[];
  customerName: string;
  customerEmail: string;
  onError?: (message: string) => void;
  className?: string;
  label?: string;
  apiBasePath?: string; // default: "/api"
};

type CheckoutState =
  | { phase: "idle" }
  | { phase: "loading" }
  | { phase: "redirecting" }
  | { phase: "error"; message: string };

// ─── Componente ───────────────────────────────────────────────────────────────

export function NexiCheckoutButton({
  items,
  customerName,
  customerEmail,
  onError,
  className = "",
  label = "Paga ora",
  apiBasePath = "/api",
}: NexiCheckoutButtonProps) {
  const [state, setState] = useState<CheckoutState>({ phase: "idle" });

  const handlePay = async () => {
    if (state.phase === "loading" || state.phase === "redirecting") return;

    // Validazione lato client
    if (!customerName.trim() || !customerEmail.trim()) {
      const msg = "Inserisci nome e email prima di procedere";
      setState({ phase: "error", message: msg });
      onError?.(msg);
      return;
    }
    if (items.length === 0) {
      const msg = "Il carrello è vuoto";
      setState({ phase: "error", message: msg });
      onError?.(msg);
      return;
    }

    setState({ phase: "loading" });

    try {
      const res = await fetch(`${apiBasePath}/checkout/create-order`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ customerName, customerEmail, items }),
      });

      if (!res.ok) {
        const data = (await res.json()) as { error?: string };
        throw new Error(data.error ?? "Errore del server");
      }

      const { hostedPage } = (await res.json()) as { hostedPage: string };

      setState({ phase: "redirecting" });
      window.location.href = hostedPage;
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Errore imprevisto. Riprova.";
      setState({ phase: "error", message });
      onError?.(message);
    }
  };

  const isLoading =
    state.phase === "loading" || state.phase === "redirecting";

  return (
    <div>
      <button
        onClick={handlePay}
        disabled={isLoading}
        className={className}
        style={
          className
            ? undefined
            : {
                padding: "12px 24px",
                background: isLoading ? "#999" : "#1a56db",
                color: "#fff",
                border: "none",
                borderRadius: "8px",
                fontSize: "16px",
                fontWeight: 600,
                cursor: isLoading ? "not-allowed" : "pointer",
                transition: "background 0.2s",
              }
        }
      >
        {state.phase === "loading" && "Creazione ordine..."}
        {state.phase === "redirecting" && "Reindirizzamento a Nexi..."}
        {(state.phase === "idle" || state.phase === "error") && label}
      </button>

      {state.phase === "error" && (
        <p
          style={{ color: "#dc2626", marginTop: "8px", fontSize: "14px" }}
          role="alert"
        >
          {state.message}
        </p>
      )}
    </div>
  );
}
