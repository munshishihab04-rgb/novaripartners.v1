/**
 * NEXI XPAY HPP — Pagina di Risultato Pagamento
 *
 * Questa pagina viene mostrata quando Nexi reindirizza il cliente
 * dopo il pagamento (sia OK che KO). Verifica sempre lo stato reale
 * chiamando il tuo backend, non fidarti del solo redirect.
 *
 * Route: /order-success?orderId=...
 *
 * Come usare (esempio con react-router-dom):
 *   <Route path="/order-success" element={<OrderResultPage />} />
 *
 * Come usare (esempio con wouter):
 *   <Route path="/order-success" component={OrderResultPage} />
 */

import { useEffect, useState } from "react";

// ─── Tipi ─────────────────────────────────────────────────────────────────────

type PaymentStatus = "loading" | "paid" | "failed" | "cancelled" | "pending";

type VerifyResponse = {
  orderId: string;
  status: string;
  operationResult?: string;
};

// ─── Componente ───────────────────────────────────────────────────────────────

type OrderResultPageProps = {
  apiBasePath?: string;       // default "/api"
  successRedirectTo?: string; // path da aprire dopo successo (opzionale)
  failRedirectTo?: string;    // path da aprire dopo fallimento (opzionale)
};

export function OrderResultPage({
  apiBasePath = "/api",
  successRedirectTo,
  failRedirectTo,
}: OrderResultPageProps) {
  const [status, setStatus] = useState<PaymentStatus>("loading");
  const [orderId, setOrderId] = useState<string>("");
  const [attempts, setAttempts] = useState(0);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const id = params.get("orderId") ?? "";
    const mock = params.get("mock");
    setOrderId(id);

    if (!id) {
      setStatus("failed");
      return;
    }

    // Polling: verifica ogni 2 secondi per max 10 volte (20 secondi)
    let tries = 0;
    const MAX_TRIES = 10;

    const poll = async () => {
      try {
        const url = mock
          ? `${apiBasePath}/checkout/verify/${id}?mock=${mock}`
          : `${apiBasePath}/checkout/verify/${id}`;

        const res = await fetch(url);
        if (!res.ok) throw new Error("Errore di rete");

        const data = (await res.json()) as VerifyResponse;
        const s = data.status as PaymentStatus;

        if (s === "paid" || s === "failed" || s === "cancelled") {
          setStatus(s);

          // Redirect automatico opzionale
          if (s === "paid" && successRedirectTo) {
            setTimeout(() => {
              window.location.href = successRedirectTo;
            }, 3000);
          }
          if ((s === "failed" || s === "cancelled") && failRedirectTo) {
            setTimeout(() => {
              window.location.href = failRedirectTo;
            }, 3000);
          }
          return; // stop polling
        }

        // Ancora pending
        tries++;
        setAttempts(tries);
        if (tries < MAX_TRIES) {
          setTimeout(poll, 2000);
        } else {
          setStatus("pending");
        }
      } catch {
        setStatus("failed");
      }
    };

    poll();
  }, [apiBasePath, successRedirectTo, failRedirectTo]);

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        {status === "loading" && (
          <>
            <div style={styles.spinner} />
            <h2 style={styles.title}>Verifica pagamento...</h2>
            <p style={styles.subtitle}>
              Stiamo controllando lo stato del tuo ordine
              {attempts > 0 ? ` (tentativo ${attempts}/10)` : ""}
            </p>
          </>
        )}

        {status === "paid" && (
          <>
            <div style={{ ...styles.icon, color: "#16a34a" }}>✓</div>
            <h2 style={{ ...styles.title, color: "#16a34a" }}>
              Pagamento confermato!
            </h2>
            <p style={styles.subtitle}>
              Ordine <strong>{orderId}</strong> pagato con successo.
            </p>
            <p style={styles.meta}>Riceverai una conferma via email.</p>
          </>
        )}

        {status === "failed" && (
          <>
            <div style={{ ...styles.icon, color: "#dc2626" }}>✗</div>
            <h2 style={{ ...styles.title, color: "#dc2626" }}>
              Pagamento non riuscito
            </h2>
            <p style={styles.subtitle}>
              Il pagamento per l&apos;ordine <strong>{orderId}</strong> non è
              andato a buon fine.
            </p>
            <a href="/cart" style={styles.button}>
              Torna al carrello
            </a>
          </>
        )}

        {status === "cancelled" && (
          <>
            <div style={{ ...styles.icon, color: "#d97706" }}>⊘</div>
            <h2 style={{ ...styles.title, color: "#d97706" }}>
              Pagamento annullato
            </h2>
            <p style={styles.subtitle}>Hai annullato il pagamento.</p>
            <a href="/cart" style={styles.button}>
              Torna al carrello
            </a>
          </>
        )}

        {status === "pending" && (
          <>
            <div style={{ ...styles.icon, color: "#2563eb" }}>⟳</div>
            <h2 style={{ ...styles.title, color: "#2563eb" }}>
              Pagamento in elaborazione
            </h2>
            <p style={styles.subtitle}>
              Il pagamento è ancora in corso. Riceverai un&apos;email di
              conferma appena elaborato.
            </p>
          </>
        )}
      </div>
    </div>
  );
}

// ─── Stili inline (sostituibili con Tailwind/CSS) ─────────────────────────────

const styles: Record<string, React.CSSProperties> = {
  page: {
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    background: "#f9fafb",
    fontFamily: "sans-serif",
    padding: "24px",
  },
  card: {
    background: "#fff",
    borderRadius: "16px",
    padding: "48px 40px",
    maxWidth: "480px",
    width: "100%",
    textAlign: "center",
    boxShadow: "0 4px 24px rgba(0,0,0,0.08)",
  },
  icon: {
    fontSize: "64px",
    marginBottom: "16px",
    lineHeight: 1,
  },
  spinner: {
    width: "48px",
    height: "48px",
    border: "4px solid #e5e7eb",
    borderTop: "4px solid #2563eb",
    borderRadius: "50%",
    margin: "0 auto 24px",
    animation: "spin 1s linear infinite",
  },
  title: {
    fontSize: "24px",
    fontWeight: 700,
    margin: "0 0 12px",
    color: "#111827",
  },
  subtitle: {
    fontSize: "16px",
    color: "#4b5563",
    margin: "0 0 8px",
  },
  meta: {
    fontSize: "14px",
    color: "#9ca3af",
    margin: "8px 0 0",
  },
  button: {
    display: "inline-block",
    marginTop: "24px",
    padding: "10px 24px",
    background: "#1a56db",
    color: "#fff",
    textDecoration: "none",
    borderRadius: "8px",
    fontWeight: 600,
    fontSize: "15px",
  },
};
