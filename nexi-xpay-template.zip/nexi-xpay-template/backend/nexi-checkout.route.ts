/**
 * NEXI XPAY HPP — Route Express (Backend)
 *
 * Come usare:
 *   import nexiRouter from "./nexi-checkout.route";
 *   app.use("/api", nexiRouter);
 *
 * Espone:
 *   POST /api/checkout/create-order   → crea ordine su Nexi, restituisce hostedPage URL
 *   GET  /api/checkout/verify/:id     → verifica stato pagamento
 *   POST /api/checkout/notify         → webhook server-to-server da Nexi
 */

import { Router, Request, Response } from "express";
import { randomBytes, randomUUID } from "crypto";
import {
  NEXI_API_KEY,
  NEXI_BASE_URL,
  getSiteUrl,
  CURRENCY,
  LANGUAGE,
  ORDER_ID_PREFIX,
  RESULT_PATH,
  CANCEL_PATH,
  API_BASE_PATH,
} from "../config/nexi.config";

const router = Router();

// ─── Tipi ─────────────────────────────────────────────────────────────────────

type CartItem = {
  id: string;
  name: string;
  price: number;    // prezzo unitario in unità (es. 29.99)
  quantity: number;
};

type CreateOrderBody = {
  customerName?: string;
  customerEmail?: string;
  items?: CartItem[];
  currency?: string; // opzionale, sovrascrive il default
};

type NexiHppResponse = {
  hostedPage: string;
  securityToken: string;
};

type NexiOrderResponse = {
  operations?: Array<{
    operationResult: string;
    operationId: string;
    operationTime: string;
    operationType: string;
    paymentMethod: string;
    paymentCircuit: string;
    paymentInstrumentInfo: string;
    paymentEndToEndId: string;
    cancelledOperationId: string;
    operationAmount: string;
    operationCurrency: string;
    customerInfo: Record<string, string>;
    warnings: string[];
    additionalData: Record<string, string>;
  }>;
};

// ─── Helper ───────────────────────────────────────────────────────────────────

function generateOrderId(): string {
  return `${ORDER_ID_PREFIX}${randomBytes(8).toString("hex").toUpperCase()}`;
}

function nexiHeaders(): Record<string, string> {
  return {
    "Content-Type": "application/json",
    "X-Api-Key": NEXI_API_KEY,
    "Correlation-Id": randomUUID(),
  };
}

function mapOperationResult(result: string): "paid" | "failed" | "cancelled" | "pending" {
  if (result === "AUTHORIZED" || result === "EXECUTED") return "paid";
  if (result === "DECLINED" || result === "FAILED" || result === "VOIDED") return "failed";
  if (result === "CANCELLED") return "cancelled";
  return "pending";
}

// ─── POST /checkout/create-order ─────────────────────────────────────────────

router.post("/checkout/create-order", async (req: Request, res: Response) => {
  const { customerName, customerEmail, items, currency } =
    req.body as CreateOrderBody;

  // Validazione input
  if (!customerName?.trim() || !customerEmail?.trim()) {
    res.status(400).json({ error: "Nome e email cliente sono obbligatori" });
    return;
  }
  if (!items || items.length === 0) {
    res.status(400).json({ error: "Il carrello è vuoto" });
    return;
  }

  const activeCurrency = currency ?? CURRENCY;
  const totalAmount = items.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );
  const amountCents = Math.round(totalAmount * 100);

  if (amountCents <= 0) {
    res.status(400).json({ error: "Importo non valido" });
    return;
  }

  const orderId = generateOrderId();
  const siteUrl = getSiteUrl();

  // Modalità sviluppo: NEXI_API_KEY non configurata
  if (!NEXI_API_KEY) {
    console.warn("[Nexi] NEXI_API_KEY non impostata — modalità mock attiva");
    res.json({
      hostedPage: `${siteUrl}${RESULT_PATH}?orderId=${orderId}&mock=1`,
      orderId,
      amountCents,
      currency: activeCurrency,
      mock: true,
    });
    return;
  }

  const description = items
    .map((i) => `${i.quantity}x ${i.name}`)
    .join(", ")
    .slice(0, 200);

  // Chiamata a Nexi HPP
  const nexiResponse = await fetch(`${NEXI_BASE_URL}/orders/hpp`, {
    method: "POST",
    headers: nexiHeaders(),
    body: JSON.stringify({
      order: {
        orderId,
        amount: String(amountCents),
        currency: activeCurrency,
        description,
        customerInfo: {
          cardHolderName: customerName.trim(),
          cardHolderEmail: customerEmail.trim(),
        },
      },
      paymentSession: {
        actionType: "PAY",
        amount: String(amountCents),
        currency: activeCurrency,
        language: LANGUAGE,
        resultUrl: `${siteUrl}${RESULT_PATH}?orderId=${orderId}`,
        cancelUrl: `${siteUrl}${CANCEL_PATH}`,
        notificationUrl: `${siteUrl}${API_BASE_PATH}/checkout/notify`,
      },
    }),
  });

  if (!nexiResponse.ok) {
    const errBody = await nexiResponse.text();
    console.error("[Nexi] Errore HPP:", nexiResponse.status, errBody);
    res.status(502).json({
      error: "Errore del gateway di pagamento. Riprova tra qualche minuto.",
    });
    return;
  }

  const nexiData = (await nexiResponse.json()) as NexiHppResponse;

  // ──────────────────────────────────────────────────────────────────────────
  // OPZIONALE: salva ordine nel tuo database qui prima di rispondere
  // await db.insert(ordersTable).values({ id: orderId, status: "pending", ... });
  // ──────────────────────────────────────────────────────────────────────────

  res.json({
    hostedPage: nexiData.hostedPage,
    orderId,
    amountCents,
    currency: activeCurrency,
  });
});

// ─── GET /checkout/verify/:orderId ───────────────────────────────────────────

router.get("/checkout/verify/:orderId", async (req: Request, res: Response) => {
  const { orderId } = req.params;

  if (!orderId) {
    res.status(400).json({ error: "orderId mancante" });
    return;
  }

  // Modalità mock (senza chiave API)
  if (!NEXI_API_KEY) {
    const mockPaid = req.query.mock === "1";
    res.json({ orderId, status: mockPaid ? "paid" : "pending" });
    return;
  }

  const nexiResponse = await fetch(`${NEXI_BASE_URL}/orders/${orderId}`, {
    headers: nexiHeaders(),
  });

  if (!nexiResponse.ok) {
    res.status(502).json({ error: "Impossibile verificare l'ordine con Nexi" });
    return;
  }

  const nexiOrder = (await nexiResponse.json()) as NexiOrderResponse;
  const operations = nexiOrder.operations ?? [];
  const latestOp = operations[operations.length - 1];
  const operationResult = latestOp?.operationResult ?? "UNKNOWN";
  const status = mapOperationResult(operationResult);

  // ──────────────────────────────────────────────────────────────────────────
  // OPZIONALE: aggiorna stato ordine nel database
  // await db.update(ordersTable).set({ status }).where(eq(ordersTable.id, orderId));
  // ──────────────────────────────────────────────────────────────────────────

  res.json({ orderId, status, operationResult });
});

// ─── POST /checkout/notify (webhook Nexi) ────────────────────────────────────

router.post("/checkout/notify", async (req: Request, res: Response) => {
  console.info("[Nexi] Notifica ricevuta:", JSON.stringify(req.body));

  // ──────────────────────────────────────────────────────────────────────────
  // OPZIONALE: estrai orderId e aggiorna il database
  //
  // const { orderId, operationResult } = req.body;
  // if (orderId && operationResult) {
  //   const status = mapOperationResult(operationResult);
  //   await db.update(ordersTable).set({ status }).where(eq(ordersTable.id, orderId));
  // }
  // ──────────────────────────────────────────────────────────────────────────

  res.status(200).json({ received: true });
});

export default router;
