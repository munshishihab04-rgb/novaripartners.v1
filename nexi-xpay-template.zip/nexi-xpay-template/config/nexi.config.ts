/**
 * NEXI XPAY HPP — Configurazione Centrale
 *
 * Modifica solo questo file per adattare l'integrazione al tuo progetto.
 * Tutte le altre parti del template leggono da qui.
 */

// ─── 1. AMBIENTE ─────────────────────────────────────────────────────────────
// "sandbox"    → nessun addebito reale, usa carte di test
// "production" → addebiti reali, usa la chiave API di produzione
export const NEXI_ENV = (process.env.NEXI_ENV ?? "sandbox") as
  | "sandbox"
  | "production";

// ─── 2. CHIAVE API ───────────────────────────────────────────────────────────
// Imposta NEXI_API_KEY come variabile d'ambiente (mai nel codice sorgente!)
// Sandbox test key (implicit capture): 2e570a58-9914-477a-9ede-35baff23a376
// Sandbox test key (explicit capture): ee6a41f2-fa09-4b8f-bc05-5dc225bdc270
export const NEXI_API_KEY = process.env.NEXI_API_KEY ?? "";

// ─── 3. URL BASE NEXI ────────────────────────────────────────────────────────
export const NEXI_BASE_URL =
  NEXI_ENV === "production"
    ? "https://xpay.nexigroup.com/api/phoenix-0.0/psp/api/v1"
    : "https://xpaysandbox.nexigroup.com/api/phoenix-0.0/psp/api/v1";

// ─── 4. URL DEL TUO SITO ─────────────────────────────────────────────────────
// Usato per costruire resultUrl, cancelUrl, notificationUrl
// Esempi: "https://mionegozio.com", "https://xyz.replit.app"
export function getSiteUrl(): string {
  if (process.env.SITE_URL) return process.env.SITE_URL.replace(/\/$/, "");
  // Supporto automatico Replit
  const domains = process.env.REPLIT_DOMAINS?.split(",");
  if (domains?.length) return `https://${domains[0].trim()}`;
  if (process.env.REPLIT_DEV_DOMAIN)
    return `https://${process.env.REPLIT_DEV_DOMAIN}`;
  throw new Error("SITE_URL non configurato");
}

// ─── 5. PREFISSO API ─────────────────────────────────────────────────────────
// Se il tuo Express serve su /api cambia qui
export const API_BASE_PATH = "/api";

// ─── 6. PAGINE DI RITORNO ────────────────────────────────────────────────────
// Path frontend dove Nexi reindirizza dopo il pagamento
// resultUrl: viene chiamato sia per OK che per KO → verifica sempre lo stato
// cancelUrl: cliente ha premuto "Annulla" su Nexi
export const RESULT_PATH = "/order-success"; // ?orderId=... viene aggiunto automaticamente
export const CANCEL_PATH = "/cart";

// ─── 7. VALUTA E LINGUA ──────────────────────────────────────────────────────
export const CURRENCY = "EUR"; // ISO 4217: EUR, USD, GBP...
export const LANGUAGE = "ita"; // ita, eng, fra, deu, spa, por

// ─── 8. PREFISSO ORDER ID ────────────────────────────────────────────────────
// Prefisso identificativo nei tuoi ordini Nexi (es. "NK" → NK3F8A2B1C...)
export const ORDER_ID_PREFIX = "ORD";
