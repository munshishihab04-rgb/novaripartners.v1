# Nexi XPay HPP — Template Pronto all'Uso

Questo template permette di integrare il gateway di pagamento **Nexi XPay**
in qualsiasi e-commerce con architettura **Express (backend) + React (frontend)**.

> **Per farlo partire ti serve solo la chiave API Nexi.**

---

## Struttura del Template

```
nexi-xpay-template/
├── config/
│   └── nexi.config.ts          ← UNICO FILE DA MODIFICARE
├── backend/
│   └── nexi-checkout.route.ts  ← Router Express, copia e registra
├── frontend/
│   ├── NexiCheckoutButton.tsx  ← Bottone "Paga ora" React
│   └── OrderResultPage.tsx     ← Pagina successo/fallimento
└── .env.example                ← Variabili d'ambiente richieste
```

---

## Avvio Rapido (5 passi)

### Passo 1 — Copia i file nel tuo progetto

```
config/nexi.config.ts         → src/config/nexi.config.ts
backend/nexi-checkout.route.ts → src/routes/nexi-checkout.route.ts
frontend/NexiCheckoutButton.tsx → src/components/NexiCheckoutButton.tsx
frontend/OrderResultPage.tsx   → src/pages/OrderResultPage.tsx
```

### Passo 2 — Imposta le variabili d'ambiente

Crea un file `.env` nella root del progetto (copia da `.env.example`):

```env
NEXI_API_KEY=la-tua-chiave-api
NEXI_ENV=sandbox          # usa "production" solo quando sei pronto
SITE_URL=https://miosito.com
```

> ⚠️ **Non committare mai `.env` su Git.** Aggiungi `.env` al `.gitignore`.

### Passo 3 — Registra il router nel tuo Express

```typescript
// app.ts o index.ts
import express from "express";
import nexiRouter from "./routes/nexi-checkout.route";

const app = express();
app.use(express.json());
app.use("/api", nexiRouter);  // espone /api/checkout/create-order ecc.
```

### Passo 4 — Aggiungi le route React

```typescript
// Esempio con react-router-dom
import { OrderResultPage } from "./pages/OrderResultPage";

<Routes>
  <Route path="/order-success" element={<OrderResultPage />} />
  {/* le altre route del tuo sito */}
</Routes>

// Esempio con wouter
import { OrderResultPage } from "./pages/OrderResultPage";

<Route path="/order-success" component={OrderResultPage} />
```

### Passo 5 — Usa il bottone nel tuo checkout

```tsx
import { NexiCheckoutButton } from "./components/NexiCheckoutButton";

function CheckoutPage() {
  const cartItems = [
    { id: "prod-1", name: "Prodotto A", price: 29.99, quantity: 2 },
  ];

  return (
    <NexiCheckoutButton
      items={cartItems}
      customerName="Mario Rossi"
      customerEmail="mario@example.com"
    />
  );
}
```

**Fatto.** Il cliente viene reindirizzato su Nexi, paga, e torna alla tua pagina `/order-success`.

---

## Dipendenze

### Backend (Node.js / Express)

Nessuna dipendenza aggiuntiva — il template usa solo le API native di Node.js:
- `fetch` (Node 18+)
- `crypto` (built-in)
- `express` (già nel tuo progetto)

```bash
# Verifica di avere Node 18+
node --version
```

### Frontend (React)

Nessuna dipendenza aggiuntiva — il template usa solo React hooks standard.

---

## Configurazione — `nexi.config.ts`

Questo è il **solo file da modificare** per adattare il template al tuo progetto.

| Costante | Descrizione | Default |
|---|---|---|
| `NEXI_ENV` | `"sandbox"` o `"production"` | `"sandbox"` |
| `NEXI_API_KEY` | Letta da `process.env.NEXI_API_KEY` | — |
| `CURRENCY` | Valuta ISO 4217 | `"EUR"` |
| `LANGUAGE` | Lingua pagina Nexi | `"ita"` |
| `RESULT_PATH` | Path frontend risultato pagamento | `"/order-success"` |
| `CANCEL_PATH` | Path frontend quando cliente annulla | `"/cart"` |
| `API_BASE_PATH` | Prefisso API nel tuo Express | `"/api"` |
| `ORDER_ID_PREFIX` | Prefisso degli order ID Nexi | `"ORD"` |

---

## Flusso Completo

```
Cliente clicca "Paga ora"
        │
        ▼
NexiCheckoutButton → POST /api/checkout/create-order
        │
        ▼
Backend chiama Nexi: POST /orders/hpp
        │
        ▼
Nexi restituisce { hostedPage }
        │
        ▼
Frontend: window.location.href = hostedPage
        │
        ▼
Cliente inserisce carta su PAGINA SICURA NEXI (non sul tuo sito)
        │
        ├─ Pagamento OK ──► Nexi → resultUrl = /order-success?orderId=...
        │                              │
        │                              ▼
        │                  OrderResultPage → GET /api/checkout/verify/:id
        │                              │
        │                              ▼
        │                  Mostra "Pagamento confermato ✓"
        │
        ├─ Pagamento KO ──► Nexi → resultUrl = /order-success?orderId=...
        │                              │
        │                              ▼
        │                  OrderResultPage → verifica → "Non riuscito ✗"
        │
        └─ Cliente annulla ──► Nexi → cancelUrl = /cart
```

> **Nota:** `resultUrl` viene chiamato sia per pagamenti riusciti che falliti.
> La pagina `OrderResultPage` chiama sempre `/api/checkout/verify/:id` per
> sapere lo stato reale — non fidarsi solo del redirect.

---

## Test in Sandbox

**1.** Imposta `NEXI_ENV=sandbox` e usa la chiave di test:
```
NEXI_API_KEY=2e570a58-9914-477a-9ede-35baff23a376
```

**2.** Carta di test Nexi:
| Campo | Valore |
|---|---|
| Numero carta | `4539970000000006` |
| Scadenza | qualsiasi data futura |
| CVV | `123` |
| Titolare | qualsiasi nome |

**3.** Per simulare un pagamento rifiutato usa: `4000000000000002`

---

## Modalità Sviluppo Locale (senza chiave)

Se `NEXI_API_KEY` non è impostata, il backend restituisce automaticamente un
URL mock che porta direttamente alla pagina di successo, **senza chiamare Nexi**.
Utile per sviluppare il frontend senza una chiave.

```
POST /api/checkout/create-order
→ { hostedPage: "http://localhost:3000/order-success?orderId=...&mock=1" }
```

---

## Passaggio a Produzione

1. Ottieni la chiave di produzione dal **Portale Nexi Merchant**
2. Aggiorna le variabili d'ambiente:
   ```env
   NEXI_API_KEY=chiave-produzione-nexi
   NEXI_ENV=production
   SITE_URL=https://miosito.com
   ```
3. Verifica che `SITE_URL` sia l'URL **pubblico** del sito (non localhost)
4. Nexi deve poter raggiungere `SITE_URL/api/checkout/notify` per i webhook

---

## Personalizzazioni Comuni

### Aggiungere il salvataggio ordini nel database

Nel file `nexi-checkout.route.ts` ci sono commenti `// OPZIONALE:` che indicano
dove aggiungere le chiamate al database:

```typescript
// Dopo la chiamata Nexi riuscita in create-order:
await db.insert(ordersTable).values({
  id: orderId,
  customerName,
  customerEmail,
  amountCents,
  currency: activeCurrency,
  status: "pending",
});

// In verify/:orderId dopo la risposta Nexi:
await db.update(ordersTable)
  .set({ status })
  .where(eq(ordersTable.id, orderId));

// In /notify per aggiornamenti asincroni:
const { orderId, operationResult } = req.body;
const status = mapOperationResult(operationResult);
await db.update(ordersTable).set({ status }).where(eq(ordersTable.id, orderId));
```

### Cambiare la valuta

```typescript
// nexi.config.ts
export const CURRENCY = "USD"; // oppure GBP, CHF, ecc.
```

### Cambiare la lingua della pagina Nexi

```typescript
// nexi.config.ts
export const LANGUAGE = "eng"; // ita, eng, fra, deu, spa, por
```

### Usare la tua UI per il bottone

`NexiCheckoutButton` accetta `className` per applicare i tuoi stili:

```tsx
<NexiCheckoutButton
  items={cartItems}
  customerName={name}
  customerEmail={email}
  className="btn btn-primary w-full"
  label="Procedi al pagamento"
/>
```

### Multi-valuta (EUR e USD)

```tsx
// Passa currency come prop aggiuntiva al backend
const res = await fetch("/api/checkout/create-order", {
  method: "POST",
  body: JSON.stringify({ customerName, customerEmail, items, currency: "USD" }),
});
```

Il backend accetta il campo `currency` nel body e lo usa al posto del default.

---

## Webhook — Notifica Server-to-Server

Nexi chiama `POST /api/checkout/notify` in modo **asincrono** quando il
pagamento cambia stato. Questo è utile per aggiornare il database anche se
il cliente chiude il browser prima del redirect.

Il corpo della notifica Nexi ha questa struttura:
```json
{
  "orderId": "ORD3F8A2B1C...",
  "operationId": "...",
  "operationResult": "AUTHORIZED",
  "operationType": "AUTHORIZATION",
  "paymentMethod": "CARD",
  "paymentCircuit": "VISA"
}
```

Vedi il commento `// OPZIONALE:` in `/checkout/notify` nel route file.

---

## Checklist Finale Prima del Go-Live

- [ ] `NEXI_ENV=production`
- [ ] `NEXI_API_KEY` = chiave di produzione (non sandbox)
- [ ] `SITE_URL` = URL pubblico HTTPS del sito
- [ ] `/api/checkout/notify` raggiungibile da internet (per webhook Nexi)
- [ ] Testato un pagamento completo in sandbox con carta di test
- [ ] `.env` non presente nel repository Git
- [ ] HTTPS attivo sul sito (Nexi non accetta HTTP in produzione)
